package selfstudying1;

public class SelfStudy17 {


    /*
public static void main(String[] args) {
updateWord("john", "black");
}
public static void updateWord(String s, String t) {
s = s.substring(0,1).toUpperCase() + t.substring(2);
System.out.println(s);
}
Output nedir?
A) Jack
B) Joack
C) Jck
D) Compile Time Error



     */


















    /*

    Bu soruda, updateWord isimli bir metod tanımlandı ve bu metod, iki adet string parametre alır.
    Metod, ilk parametrenin ilk harfini büyük harf yapar ve
    ikinci parametrenin ikinci harfi ile birleştirerek yeni bir string oluşturur.
    Oluşturulan bu yeni string ekrana yazdırılır.

main metodunda ise updateWord metoduna "john" ve "black" stringleri gönderilir.

Metodun çalışması sonucunda oluşan string "Black" olur ve bu string ekrana yazdırılır.

Yani, çıktı "Black" olacaktır. Doğru cevap A'dır.

     */
}
