package day30abstraction;

public class CoursesRunner {

    public static void main(String[] args) {


       //class'imizdan bir obje uretelim.
       //Courses courses=new Courses();//bu sekilde yazinca kirmizi uyari verdi cunku abstract class'tan obje
        //uretilemez.

    }
}
