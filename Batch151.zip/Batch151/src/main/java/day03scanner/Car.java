package day03scanner;

public class Car {
      //Variable'lar olusturalim
    public String model = "Corolla";
    public int fiyat = 20000;


    //method'lar olusturalim
    //Note:"return type void oldugunda method icinde "return" keyword'u kullanilmaz
    //eger bir method yeni bir data uretmiyor sadece belli bir islem yapiyorsa return type'i void olur
    public void hareket() {
        System.out.println("Corolla hizli harejet eder...");

    }
    public void dur() {

        System.out.println("Corolla guvenli bir sekilde durur...");
    }



}
