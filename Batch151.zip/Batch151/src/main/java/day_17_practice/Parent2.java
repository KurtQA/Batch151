package day_17_practice;

public class Parent2 {
}
