package selfstudying1;

public class SelfStudy15 {
//    public static void multiply(int num1, int num2) {
//        System.out.println(num1* num2);
//    }
//    public static void multiply(int num1) {
//        System.out.println(num1*num1);
//    }
//    public static void multiply(double num1, double num2) {
//        System.out.println(num1* num2);
//    }
//    Hangisi yanlıştır?
//    A) public static void main(String[] args) {
//        multiply(3, 5);
//    }
//    Ekrana 15 yazar.
//            B) public static void main(String[] args) {
//        multiply(5);
//    }
//    Ekrana 25 yazar
//    C) public static void main(String[] args) {
//        multiply(2.5);
//    }
//    Ekrana 4 yazar
//    D) public static void main(String[] args) {
//        multiply(2.5, 2.5);
//    }
//    Ekrana 6.25 yazar























//    Bu soruda, multiply isimli üç adet metod tanımlandı.
//    Her bir metod aldığı parametrelere göre farklı işlemler yapar ve sonuçları ekrana yazdırır.
//
//            A) multiply(3, 5) ifadesi, iki adet integer parametre alan multiply metodunu çağırır.
//            Bu metod, verilen parametrelerin çarpımını hesaplar ve sonucu ekrana yazdırır.
//            Sonuç olarak ekrana 15 yazdırılır. Doğru cevap A'dır.
//
//    B) multiply(5) ifadesi, tek bir integer parametre alan multiply metodunu çağırır.
//    Bu metod, verilen sayının karesini hesaplar ve sonucu ekrana yazdırır.
//    Sonuç olarak ekrana 25 yazdırılır. Doğru cevap B'dir.
//
//    C) multiply(2.5) ifadesi, tek bir double parametre alan multiply metodunu çağırır.
//    Bu metod, verilen sayının karesini hesaplar ve sonucu ekrana yazdırır. Ancak, burada dikkat edilmesi gereken nokta, verilen parametrenin double olduğudur. Bu nedenle, metod çağrılırken parametrenin tam olarak eşleştiği public static void multiply(double num1, double num2) metodunu değil, public static void multiply(int num1) metodunu çağırmaktadır. Bu nedenle sonuç olarak ekrana 4 değil, 6.25 yazdırılması gerekir. Cevap yanlıştır.
//
//    D) multiply(2.5, 2.5) ifadesi, iki adet double parametre alan multiply metodunu çağırır.
//    Bu metod, verilen parametrelerin çarpımını hesaplar ve sonucu ekrana yazdırır. Sonuç olarak ekrana 6.25 yazdırılır. Doğru cevap D'dir.
//
//    Sonuç olarak, C şıkkı yanlıştır, diğer şıklar doğrudur.



}
