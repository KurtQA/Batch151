package day23inheritance;

public class Dog extends Animal{

    public void bark(){

        System.out.println("Dogs bark...");
    }
}
