package day28interface;

public class Dog implements Animal.Mammal {

    @Override
    public void eat() {

    }

    @Override
    public void drink() {

    }

}