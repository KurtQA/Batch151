package lambda_recap;

public class Utils {

    public static void yazdir(Object a){
        System.out.print(a + " ");
    }


    public static int kareBul(int a){

        return a*a;
    }




}