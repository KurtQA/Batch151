package day26abstraction;

//public class Test2 extends Test{
//} Test Class'ini final yaptiktan sonra Test2 classini Test clasinin childi yapmaya calisinca en sondaki Test
//yazisi uyari verdi. Final class'in child'i olamaz
