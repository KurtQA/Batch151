package day28interface;

public interface Mammal extends Animal {
        String feedBaby = "Milk";
        int age = 6;

    }

