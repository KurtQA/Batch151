package selfstudying1;

public class SelfStudy12 {

    public static void main(String[] args) {

        //Example: Size verilen kucuk harfle yazilmis String'in index'i cift sayi olan character'lerini buyuk harfe donusturun

        //ankara==>AKR

        String s="ankara";
//         for(int i=0; i<s.length(); i++){
//             String y= s.substring(i,i+1).toUpperCase();
//             if(i%2==0){
//                 System.out.print(y);
           //  }

         //}

         //Example: Verilen bir String'de ilk 'a' harfinden onceki tum karakterleri console'a yazdirin
        //"I love Java";

//        String p="I love Java";
//         for(int i=0; i<p.length()) ;i++){
//    if(p.charAt(i)=='a'){
//        break;
//    }
//            System.out.println(p.charAt(i));
//        }

    }
}
