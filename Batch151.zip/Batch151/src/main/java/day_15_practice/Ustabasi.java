package day_15_practice;

public class Ustabasi extends Isci{
}
