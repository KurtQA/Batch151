package day26abstraction;

public class Sixth extends Courses{
    public void math(){
        System.out.println("Learn addition and substraction");
    }



}
