package day30abstraction;

public class Sixth extends Courses{
    @Override
    public void math() {
        System.out.println("Altinci sinif mufredati");
    }
}
