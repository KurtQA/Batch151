package day25varargsinheritance;

public class Car {

    public Car(){
        System.out.println("Car 1");
    }


    public String model="car model";
    public int km=20000;
}
