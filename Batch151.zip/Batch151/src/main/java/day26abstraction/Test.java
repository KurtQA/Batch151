package day26abstraction;

public final class Test {
}
