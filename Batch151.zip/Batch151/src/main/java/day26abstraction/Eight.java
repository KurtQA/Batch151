package day26abstraction;

public class Eight extends Courses{
    @Override
    public void math() {
        System.out.println("Learn Square root");
    }
}
