package day_13_practice;

public class Den1_C03_Varg {
    public static void main(String[] args) {
        String isim1="Hatice";
        String isim2="Ali";
        System.out.println(C03_Varargs.enUzunKelime(isim1, isim2));
    }
}
