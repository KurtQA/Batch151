package day30abstraction;

public class Eight extends Courses{

    @Override
    public void math() {
        System.out.println("Sekizinci sinif mufredati");
    }
}
