package day11nestedifternaryswitch;

public class C02_Ascii {


    public static void main(String[] args) {


        // Rakam kullanmadan 65, 66, 67, 68, 69, 70 sayilarinin toplamını bulunuz.


       // hic rakam kullanmadan bu rakamlarin ascii degerlerini bulup, type casting ile
        //int'e ceviririz.
        System.out.println((int)'A'+(int)'B'+(int)'C'+(int)'D'+(int)'E'+(int)'F');
    }
}
