package day23inheritance;

public class Bird extends Animal {

    public void tweet(){
        System.out.println("Birds tweet...");
    }
}
