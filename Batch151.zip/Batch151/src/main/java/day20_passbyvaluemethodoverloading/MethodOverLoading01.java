package day20_passbyvaluemethodoverloading;

public class MethodOverLoading01 {

    public static void main(String[] args) {


        String s="Java";
        //s.substring methoduna baktik. Bir parametreli ve iki parametreli substringleri gorduk.
    }

}
