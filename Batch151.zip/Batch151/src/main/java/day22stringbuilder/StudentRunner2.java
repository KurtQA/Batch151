package day22stringbuilder;

public class StudentRunner2 {
    public static void main(String[] args) {



    }
}
