package mentoring01;

import java.util.Arrays;
import java.util.Scanner;

public class Array {
    public static void main(String[] args) {

        //Arrays are used in the Java programming language to store multiple values of different data types
        // in a single variable. To define an array, you specify the data type and the size of the array.
        // The size of the array cannot be changed during the program's runtime.
        // Arrays are indexed starting from 0. To access an element of an array,
        // you use the syntax arrayName[index].

    }
}
