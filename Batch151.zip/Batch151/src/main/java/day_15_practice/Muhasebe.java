package day_15_practice;

public class Muhasebe extends Personal{
}
