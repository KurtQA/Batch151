package day_13_practice;

public class Den2_C03_Varg extends C03_Varargs {
    public static void main(String[] args) {
        String ad1="Cihan";
        String ad2="Suleyman";
        System.out.println(enUzunKelime(ad1, ad2));
    }
}