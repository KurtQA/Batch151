package day_15_practice;

public class Isci extends Muhasebe{
}
