package day_11_practice;
public class C03_Constructor {
    String marka;
    String model;
    int yil;
    String yakit;
    // marka, model, yil, yakit  seklinde dort tane instance variable olusturalım.
    // Bu variable'lara default constructor kullanarak,
    // farkli bir class'dan "Mercedes", "C180", 2023, "Benzin" deger ataması yapınız ve yazdırınız
}