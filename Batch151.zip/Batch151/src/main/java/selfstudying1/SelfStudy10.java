package selfstudying1;

public class SelfStudy10 {

    public static void main(String[] args) {



    }
}
