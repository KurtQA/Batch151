package day27interface;

public interface Run {
}
