package day_13_practice;

import day_13_practice.C03_Varargs;
public class Den3_C03_Varg {
    public static void main(String[] args) {
        String soyisim1 = "Tan";
        String soyisim2 = "Ozturk";
        System.out.println(C03_Varargs.enUzunKelime(soyisim1, soyisim2));
    }
}