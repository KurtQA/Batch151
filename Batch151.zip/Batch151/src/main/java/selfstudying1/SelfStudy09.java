package selfstudying1;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class SelfStudy09 {

    public static void main(String[] args) {

        //int num=2;
        //do{
        //   System.out.println(num+ "");
        //   num++;
        //}while(num>2); Bu kod infinite loop'a donustu.
        /*

         */
//        int num=0;
//        do{
//            System.out.println(num+ "");
//            num+=2;//Burada num icindekini 2 arttir diyor ve 8'e ulasincaya kadar her seferinde 2 artis oluyor
//        }while(num<8);//0 2 4 6
//

//        int num=0;
//        do{if(num%2==0) {
//            System.out.println(num + "");
//        }
//            num++;
//        }while(num<8);//0 2 4 6
//        int A = 4;
//        while (A < 3) {
//            System.out.println(A);
//            A++;
//            int B = 4;
//            do {
//                System.out.println(B);
//                B++;
//
//            } while (B < 3);


        //}

//        int num = 1;
//        do {
//            System.out.println(num + "");
//            num++;
//
//        } while (num < 2);




//        String str="AliCan";
//        System.out.println(str.contains("Ca"));//true
//        System.out.println(str.toUpperCase().replace('A','*'));//*LIC*N
//        System.out.println(str.substring(2,5));//iCa


    }
}
