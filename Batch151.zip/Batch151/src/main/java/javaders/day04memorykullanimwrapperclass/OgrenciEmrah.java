package javaders.day04memorykullanimwrapperclass;

public class OgrenciEmrah {
    public String name="Emrah";
    public String brans="QA";
    public int yas = 42;
    public void study(){
        System.out.println("Emrah bey gunluk duzenli calisir");
    }
    public void derseDevam(){
        System.out.println("Emrah bey duzenli canli derse katilir");
    }
}