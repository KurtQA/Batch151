package day03_lambda;

public class Utils {//gerekli methodlarin bulundugu class


    public static int karesiniAl(String s){
        return s.length() * s.length();
    }
    public static boolean ciftMi(String s){
        return s.length()%2==0;
    }

}