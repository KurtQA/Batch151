package day30abstraction;

public class Seventh extends Courses{

    @Override
    public void math() {
        System.out.println("Yedinci sinif mufredati");
    }
}
