package selfstudying1;

public class SelfStudy16 {

    /*
    public static void add(int num1, int num2) {
System.out.println(2 + num1 + num2);
}
public static void add(double num1, double num2) {
System.out.println(3 + num1 + num2);
}
Hangisi yanlıştır?
A) public static void main(String[] args) {
 add(3, 5);
}
Ekrana 10 yazar
B) public static void main(String[] args) {
 add(3.1, 5.2);
}
Ekrana 11.3 yazar
C) public static void main(String[] args) {
 add(3.1, 5);
}
D) Compile Time Error verir



     */


    /*




















Bu soruda, add isimli iki adet metod tanımlandı.
Her bir metod aldığı parametrelere göre farklı işlemler yapar ve sonuçları ekrana yazdırır.

A) add(3, 5) ifadesi, iki adet integer parametre alan add metodunu çağırır.
Bu metod, parametrelerin toplamına 2 ekler ve sonucu ekrana yazdırır. Sonuç olarak ekrana 10 yazdırılır. Doğru cevap A'dır.

B) add(3.1, 5.2) ifadesi, iki adet double parametre alan add metodunu çağırır.
Bu metod, parametrelerin toplamına 3 ekler ve sonucu ekrana yazdırır.
Sonuç olarak ekrana 11.3 yazdırılır. Doğru cevap B'dir.

C) add(3.1, 5) ifadesi, bir adet double ve bir adet integer parametre alan add metodunu çağırır.
Burada, çağrılan metodun parametreleri ile tam olarak eşleşen bir metod bulunamadığı için Java bu durumu çözümleyemez ve Compile Time Error verir. Cevap D'dir.

Sonuç olarak, C şıkkı yanlıştır, diğer şıklar doğrudur.












     */
}
