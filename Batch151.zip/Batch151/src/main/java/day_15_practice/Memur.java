package day_15_practice;



public class Memur extends Muhasebe{

}
