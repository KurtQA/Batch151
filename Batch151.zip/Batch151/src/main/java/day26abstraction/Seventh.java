package day26abstraction;

public class Seventh extends Courses{
    @Override
    public void math() {
        System.out.println("Learn multiplication and division");
    }
}
