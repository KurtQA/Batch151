package day26abstraction;

public class CoursesRunner {

    public static void main(String[] args) {


        //Courses c=new Courses(); yazinca uyari verdi. Cunku abstract'dan obje yapilamaz

        final double pi=3.14; //final keywordu eklenince deger atamasi yapilmak zorunda ve
        // atanan deger degistirilemez.
        //3.14; u cikarinca uyari veriyor.

    }
}
