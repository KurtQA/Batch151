package day03scanner;

import java.util.Scanner;

public class Scanner01tekrar {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Yasinizi giriniz");
        int age = scan.nextInt();
        System.out.println(age);

    }



}
