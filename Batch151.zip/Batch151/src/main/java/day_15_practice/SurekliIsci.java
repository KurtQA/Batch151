package day_15_practice;

public class SurekliIsci extends Isci{
}
